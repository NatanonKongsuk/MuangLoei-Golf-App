import React, { useState, useEffect } from 'react';
import { db } from '../firebase'; // ดึงตัวแปร db มาจากไฟล์คอนฟิก Firebase
import { collection, p, getDocs, doc, updateDoc, deleteDoc } from 'firebase/firestore';

function CustomerManagement() {
  const [customers, setCustomers] = useState([]); // เก็บรายชื่อลูกค้าทั้งหมด
  const [loading, setLoading] = useState(true);
  const [editingCustomer, setEditingCustomer] = useState(null); // เก็บข้อมูลลูกค้าที่กำลังจะแก้ไข
  const [editForm, setEditForm] = useState({ displayName: '', phone: '' }); // ฟอร์มแก้ไข

  // 1. ฟังก์ชันดึงข้อมูลลูกค้าจาก Firestore (Read)
  const fetchCustomers = async () => {
    setLoading(true);
    try {
      const querySnapshot = await getDocs(collection(db, 'users'));
      const customerList = [];
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        // กรองเอาเฉพาะคนที่มีสิทธิ์เป็น 'customer' (ไม่เอา owner และ staff)
        if (data.role === 'customer') {
          customerList.push({ id: doc.id, ...data });
        }
      });
      setCustomers(customerList);
    } catch (error) {
      console.error("Error fetching customers: ", error);
      alert("เกิดข้อผิดพลาดในการดึงข้อมูลลูกค้า");
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  // 2. ฟังก์ชันเปิดโหมดแก้ไข (เซ็ตค่าเริ่มต้นใส่ฟอร์ม)
  const handleEditClick = (customer) => {
    setEditingCustomer(customer.id);
    setEditForm({
      displayName: customer.displayName || '',
      phone: customer.phone || ''
    });
  };

  // 3. ฟังก์ชันบันทึกการแก้ไขข้อมูลลง Firestore (Update)
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const customerRef = doc(db, 'users', editingCustomer);
      await updateDoc(customerRef, {
        displayName: editForm.displayName,
        phone: editForm.phone
      });
      alert("อัปเดตข้อมูลลูกค้าสำเร็จ!");
      setEditingCustomer(null); // ปิดฟอร์มแก้ไข
      fetchCustomers(); // ดึงข้อมูลใหม่มาอัปเดตหน้าจอ
    } catch (error) {
      console.error("Error updating customer: ", error);
      alert("ไม่สามารถแก้ไขข้อมูลได้");
    }
  };

  // 4. ฟังก์ชันลบข้อมูลลูกค้า (Delete)
  const handleDelete = async (id) => {
    if (window.confirm("คุณแน่ใจใช่ไหมที่จะลบข้อมูลลูกค้าคนนี้? (การลบไม่สามารถกู้คืนได้)")) {
      try {
        await deleteDoc(doc(db, 'users', id));
        alert("ลบข้อมูลลูกค้าเรียบร้อยแล้ว");
        fetchCustomers(); // ดึงข้อมูลใหม่มาอัปเดตหน้าจอ
      } catch (error) {
        console.error("Error deleting customer: ", error);
        alert("ไม่สามารถลบข้อมูลได้");
      }
    }
  };

  if (loading) return <div className="text-center py-10 font-bold text-slate-500">กำลังโหลดข้อมูลลูกค้า...</div>;

  return (
    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">จัดการข้อมูลลูกค้า</h2>
        <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full">
          ทั้งหมด {customers.length} คน
        </span>
      </div>

      {/* --- ส่วนที่ 1: ฟอร์มแก้ไขข้อมูล (จะโผล่มาเมื่อกดปุ่มแก้ไข) --- */}
      {editingCustomer && (
        <form onSubmit={handleUpdate} className="mb-6 p-4 bg-slate-50 rounded-2xl border border-slate-200">
          <h3 className="text-sm font-bold text-slate-700 mb-3">📝 แก้ไขข้อมูลลูกค้า</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">ชื่อ-นามสกุล</label>
              <input
                type="text"
                value={editForm.displayName}
                onChange={(e) => setEditForm({ ...editForm, displayName: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-emerald-500"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">เบอร์โทรศัพท์</label>
              <input
                type="text"
                value={editForm.phone}
                onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>
          <div className="flex gap-2 justify-end">
            <button type="button" onClick={() => setEditingCustomer(null)} className="px-4 py-1.5 bg-slate-300 text-slate-700 font-bold rounded-xl text-xs hover:bg-slate-400">ยกเลิก</button>
            <button type="submit" className="px-4 py-1.5 bg-emerald-600 text-white font-bold rounded-xl text-xs hover:bg-emerald-700">บันทึก</button>
          </div>
        </form>
      )}

      {/* --- ส่วนที่ 2: ตารางแสดงรายชื่อลูกค้า --- */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-200 text-slate-400 text-xs uppercase font-bold">
              <th className="py-3 px-4">อีเมล</th>
              <th className="py-3 px-4">ชื่อผู้ใช้งาน</th>
              <th className="py-3 px-4">เบอร์โทร</th>
              <th className="py-3 px-4 text-center">จัดการ</th>
            </tr>
          </thead>
          <tbody className="text-slate-600 text-sm font-medium">
            {customers.map((customer) => (
              <tr key={customer.id} className="border-b border-slate-100 hover:bg-slate-50/50 transition-all">
                <td className="py-3 px-4 text-slate-800 font-semibold">{customer.email}</td>
                <td className="py-3 px-4">{customer.displayName || <span className="text-slate-300 italic">ไม่ได้ระบุ</span>}</td>
                <td className="py-3 px-4">{customer.phone || <span className="text-slate-300 italic">ไม่ได้ระบุ</span>}</td>
                <td className="py-3 px-4">
                  <div className="flex justify-center gap-2">
                    <button 
                      onClick={() => handleEditClick(customer)}
                      className="px-3 py-1 bg-amber-100 text-amber-700 text-xs font-bold rounded-lg hover:bg-amber-200"
                    >
                      แก้ไข
                    </button>
                    <button 
                      onClick={() => handleDelete(customer.id)}
                      className="px-3 py-1 bg-red-100 text-red-600 text-xs font-bold rounded-lg hover:bg-red-200"
                    >
                      ลบ
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {customers.length === 0 && (
              <tr>
                <td colSpan="4" className="text-center py-10 text-slate-400 italic">ไม่มีข้อมูลลูกค้าในระบบ</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default CustomerManagement;