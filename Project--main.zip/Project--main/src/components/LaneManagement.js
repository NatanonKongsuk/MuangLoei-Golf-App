import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, getDocs, doc, updateDoc, setDoc } from "firebase/firestore";

function LaneManagement() {
  const [lanesMap, setLanesMap] = useState({});
  const [bookingsList, setBookingsList] = useState([]); 
  const [loading, setLoading] = useState(true);
  
  const [activePopupLane, setActivePopupLane] = useState(null); 
  const [currentBooking, setCurrentBooking] = useState(null);

  const [walkInName, setWalkInName] = useState('');
  const [walkInPhone, setWalkInPhone] = useState('');
  const [walkInGuests, setWalkInGuests] = useState('1');

  const TOTAL_LANES = 15;
  const laneNumbers = Array.from({ length: TOTAL_LANES }, (_, i) => i + 1);

  const fetchData = async () => {
    setLoading(true);
    try {
      const laneSnapshot = await getDocs(collection(db, "lanes"));
      const tempLanes = {};
      laneSnapshot.forEach(doc => {
        const data = doc.data();
        if (data && data.laneNumber) tempLanes[data.laneNumber.toString()] = { id: doc.id, ...data };
      });
      setLanesMap(tempLanes);

      const bookingSnapshot = await getDocs(collection(db, "bookings"));
      const tempBookings = bookingSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setBookingsList(tempBookings);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleLaneClick = (laneNum) => {
    const laneStr = laneNum.toString();
    const laneData = lanesMap[laneStr] || { laneNumber: laneNum, status: 'available', customerName: '' };
    
    // 🟢 แก้ไขจุดที่ 1: ดักความปลอดภัยเผื่อข้อมูลว่าง และปรับให้รองรับการเช็คจองทั้งแบบ Array (selectedLanes) และแบบค่าเดี่ยว
    const matchedBooking = bookingsList.find(b => {
      if (!b) return false;
      const isStatusMatch = b.status === 'pending' || b.status === 'confirmed';
      
      // เช็คกรณีหน้า BookingFlow บันทึกเป็นอาเรย์ selectedLanes
      if (b.selectedLanes && Array.isArray(b.selectedLanes)) {
        return b.selectedLanes.map(String).includes(laneStr) && isStatusMatch;
      }
      // เช็คกรณีบันทึกเป็นฟิลด์เลนเดี่ยวตัวพิมพ์เล็กตัวพิมพ์ใหญ่
      const bLane = b.laneNumber || b.LaneNumber;
      return bLane && bLane.toString() === laneStr && isStatusMatch;
    });

    setActivePopupLane(laneData);
    setCurrentBooking(matchedBooking || null);
    
    setWalkInName('');
    setWalkInPhone('');
    setWalkInGuests('1');
  };

  const handleSaveWalkIn = async () => {
    if (!activePopupLane) return;
    if (!walkInName.trim()) {
      alert("กรุณากรอกชื่อลูกค้า Walk-in ก่อนทำการบันทึก");
      return;
    }
    try {
      const laneStr = activePopupLane.laneNumber.toString();
      const docId = `lane_${laneStr}`; // กำหนด ID รูปแบบมาตรฐานเดียวกัน
      
      // 🟢 แก้ไขจุดที่ 2: ล้างคราบข้อมูลเก่าออกโดยไม่ใช้ merge เปล่าๆ เพื่อป้องกันข้อมูลค้าง
      await setDoc(doc(db, "lanes", docId), {
        laneNumber: activePopupLane.laneNumber,
        status: "occupied",
        customerName: walkInName,
        customerPhone: walkInPhone || "",
        guestCount: walkInGuests
      });

      alert(`บันทึกข้อมูลและเปิด LANE ${laneStr} เป็นสถานะกำลังใช้งานแล้ว!`);
      setActivePopupLane(null);
      fetchData();
    } catch (error) {
      alert("เกิดข้อผิดพลาด: " + error.message);
    }
  };

  const handleCheckInBooking = async () => {
    if (!activePopupLane) return;
    try {
      const laneStr = activePopupLane.laneNumber.toString();
      const docId = `lane_${laneStr}`;
      
      await setDoc(doc(db, "lanes", docId), {
        laneNumber: activePopupLane.laneNumber,
        status: "occupied",
        customerName: currentBooking ? currentBooking.customerName : "ลูกค้าจองออนไลน์",
        customerPhone: currentBooking ? (currentBooking.phone || currentBooking.customerPhone || "") : "",
        guestCount: currentBooking ? (currentBooking.guests || currentBooking.guestCount || 1) : 1
      });

      if (currentBooking) {
        await updateDoc(doc(db, "bookings", currentBooking.id), { status: 'confirmed' });
      }

      alert("ยืนยันการเข้าใช้งาน (Check-in) เลนซ้อมเรียบร้อยแล้ว!");
      setActivePopupLane(null);
      fetchData();
    } catch (error) {
      alert("เกิดข้อผิดพลาด: " + error.message);
    }
  };

  const handleClearToAvailable = async (actionType) => {
    if (!activePopupLane) return;

    let confirmMsg = "คุณต้องการเปลี่ยนสถานะเลนนี้ให้กลับเป็น 'ว่าง' ใช่หรือไม่?";
    if (actionType === 'checkout') confirmMsg = "ยืนยันการเสร็จสิ้นการใช้งาน (เช็คเอาต์) ใช่หรือไม่?";
    if (actionType === 'cancel') confirmMsg = "คุณต้องการยกเลิกข้อมูลการจองของลูกค้ารายนี้ใช่หรือไม่?";
    if (actionType === 'open') confirmMsg = "ต้องการเปิดใช้งานเลนซ้อมนี้ตามปกติใช่หรือไม่?";

    if (window.confirm(confirmMsg)) {
      try {
        const laneStr = activePopupLane.laneNumber.toString();
        const docId = `lane_${laneStr}`;

        // เคลียร์ค่าฟิลด์ข้อมูลระบุบุคคลออกทั้งหมดให้เลนกลับมาสะอาดบริสุทธิ์
        await setDoc(doc(db, "lanes", docId), {
          laneNumber: activePopupLane.laneNumber,
          status: "available",
          customerName: "",
          customerPhone: "",
          guestCount: ""
        });

        if (actionType === 'cancel' && currentBooking) {
          await updateDoc(doc(db, "bookings", currentBooking.id), { status: 'cancelled' });
        }
        if (actionType === 'checkout' && currentBooking) {
          await updateDoc(doc(db, "bookings", currentBooking.id), { status: 'completed' });
        }

        alert("เปลี่ยนสถานะเลนเป็น 'ว่าง' เรียบร้อยแล้ว");
        setActivePopupLane(null);
        fetchData();
      } catch (error) {
        alert("เกิดข้อผิดพลาด: " + error.message);
      }
    }
  };

  const handleSetMaintenance = async () => {
    if (!activePopupLane) return;
    try {
      const laneStr = activePopupLane.laneNumber.toString();
      const docId = `lane_${laneStr}`;

      await setDoc(doc(db, "lanes", docId), {
        laneNumber: activePopupLane.laneNumber,
        status: "maintenance",
        customerName: "",
        customerPhone: "",
        guestCount: ""
      });

      alert(`เปลี่ยนเลนที่ ${laneStr} เป็นสถานะ 'ปิดปรับปรุง' เรียบร้อย`);
      setActivePopupLane(null);
      fetchData();
    } catch (error) {
      alert("Error: " + error.message);
    }
  };

  const getStatusCount = (status) => {
    let count = 0;
    laneNumbers.forEach(num => {
      const lane = lanesMap[num.toString()];
      const currentStatus = lane ? lane.status : "available";
      if (currentStatus === status) count++;
    });
    return count;
  };

  if (loading) return <div className="text-center py-10 font-bold text-slate-500">กำลังโหลดผังเลนและข้อมูล...</div>;

  return (
    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 font-sans relative">
      <div className="border-b border-slate-200 pb-4 mb-6">
        <h2 className="text-2xl font-black text-slate-800">ระบบจัดการผังสถานะเลนซ้อมกอล์ฟ</h2>
      </div>

      {/* --- แผงสรุปจำนวนเลน (Today Counter) --- */}
      <div className="bg-slate-100 p-4 rounded-2xl mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <p className="text-xl font-black text-slate-700">Today</p>
          <p className="text-xs text-slate-400 font-bold mt-0.5">สถานะเลนประจำวันนี้</p>
        </div>
        
        <div className="flex flex-wrap gap-3 font-bold text-sm">
          <div className="flex items-center gap-2 bg-[#bbf7d0] text-emerald-800 px-4 py-2 rounded-xl">
            <span>ว่าง</span>
            <span className="bg-white px-2.5 py-0.5 rounded-lg text-slate-800 font-black">{getStatusCount('available')}</span>
          </div>
          <div className="flex items-center gap-2 bg-[#99f6e4] text-teal-800 px-4 py-2 rounded-xl">
            <span>จองแล้ว</span>
            <span className="bg-white px-2.5 py-0.5 rounded-lg text-slate-800 font-black">{getStatusCount('booked')}</span>
          </div>
          <div className="flex items-center gap-2 bg-[#fde047] text-amber-800 px-4 py-2 rounded-xl">
            <span>กำลังใช้งาน</span>
            <span className="bg-white px-2.5 py-0.5 rounded-lg text-slate-800 font-black">{getStatusCount('occupied')}</span>
          </div>
          <div className="flex items-center gap-2 bg-[#fca5a5] text-red-800 px-4 py-2 rounded-xl">
            <span>ปิดปรับปรุง</span>
            <span className="bg-white px-2.5 py-0.5 rounded-lg text-slate-800 font-black">{getStatusCount('maintenance')}</span>
          </div>
        </div>
      </div>

      {/* --- แสดงผังเลนในรูปแบบ Grid --- */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-5">
        {laneNumbers.map((num) => {
          const lane = lanesMap[num.toString()];
          const currentStatus = lane ? lane.status : "available";
          
          let cardStyle = "bg-[#bbf7d0] border-emerald-400";
          let textStatus = "ว่าง";
          
          if (currentStatus === "booked") {
            cardStyle = "bg-[#67e8f9] border-cyan-400"; // อัปเดตสีฟ้าอ่อนให้ตรงสเกลหน้าจอง
            textStatus = "จองแล้ว";
          } else if (currentStatus === "occupied") {
            cardStyle = "bg-[#fde047] border-amber-400 ring-2 ring-indigo-500/50";
            textStatus = "กำลังใช้งาน";
          } else if (currentStatus === "maintenance") {
            cardStyle = "bg-[#fca5a5] border-red-400";
            textStatus = "ปิดปรับปรุง";
          }

          return (
            <div 
              key={num}
              onClick={() => handleLaneClick(num)}
              className={`p-4 rounded-2xl border-b-4 shadow-sm transition-all hover:-translate-y-1 hover:shadow-md cursor-pointer flex flex-col justify-between items-center h-44 ${cardStyle}`}
            >
              <div className="w-full h-20 bg-slate-400/30 rounded-xl flex items-center justify-center text-slate-700 text-sm font-black">
                LANE {num}
              </div>
              
              <div className="w-full text-center mt-2">
                <span className="w-full text-[11px] font-black tracking-wide text-slate-700 bg-white/90 px-4 py-1 rounded-full shadow-sm inline-block">
                  {textStatus}
                </span>
                {lane?.customerName && (
                  <p className="text-[10px] text-slate-600 font-bold truncate mt-1">👤 {lane.customerName}</p>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* --- POPUP ดีไซน์เปลี่ยนสถานะ --- */}
      {activePopupLane && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-sm bg-[#e2e2e2] rounded-[2.5rem] border-[3px] border-indigo-400/40 overflow-hidden shadow-2xl font-sans text-slate-800">
            
            <div className="bg-[#ffd41d] py-4 text-center border-b-2 border-slate-300">
              <h3 className="text-xl font-extrabold tracking-tight">เลนซ้อมที่ {activePopupLane.laneNumber}</h3>
              <p className="text-xs font-bold text-slate-600 mt-0.5">
                (สถานะปัจจุบัน: {activePopupLane.status === 'available' ? 'ว่าง' : activePopupLane.status === 'booked' ? 'จองแล้ว' : activePopupLane.status === 'occupied' ? 'กำลังใช้งาน' : 'ปิดปรับปรุง'})
              </p>
            </div>

            <div className="p-6 space-y-4">
              
              {activePopupLane.status === 'available' && (
                <div className="space-y-3">
                  <p className="text-xs font-black text-center text-emerald-700 bg-emerald-100 py-1 rounded-lg">เลนว่างอยู่ สามารถเปิดให้ลูกค้า Walk-In เข้าใช้งานได้</p>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">ชื่อลูกค้า (Walk-in)</label>
                    <input 
                      type="text"
                      value={walkInName}
                      onChange={(e) => setWalkInName(e.target.value)}
                      placeholder="กรอกชื่อลูกค้า..."
                      className="w-full bg-white p-3 rounded-xl text-sm font-bold border border-slate-300 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">เบอร์โทรติดต่อ</label>
                    <input 
                      type="text"
                      value={walkInPhone}
                      onChange={(e) => setWalkInPhone(e.target.value)}
                      placeholder="กรอกเบอร์โทร..."
                      className="w-full bg-white p-3 rounded-xl text-sm font-bold border border-slate-300 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">จำนวนผู้เข้าใช้บริการ (ท่าน)</label>
                    <input 
                      type="number"
                      min="1"
                      value={walkInGuests} 
                      onChange={(e) => setWalkInGuests(e.target.value)}
                      className="w-full bg-white p-3 rounded-xl text-sm font-bold border border-slate-300 focus:outline-none"
                    />
                  </div>
                </div>
              )}

              {activePopupLane.status !== 'available' && activePopupLane.status !== 'maintenance' && (
                <div className="space-y-3">
                  <div className="text-right text-xs font-bold text-slate-500">
                    {currentBooking?.date || new Date().toLocaleDateString('th-TH')} {currentBooking?.time || ""}
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">ชื่อลูกค้า</label>
                    <div className="w-full bg-white p-3.5 rounded-2xl text-base font-bold border border-slate-200">
                      {currentBooking?.customerName || activePopupLane.customerName}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">เบอร์โทร</label>
                    <div className="w-full bg-white p-3.5 rounded-2xl text-base font-bold border border-slate-200">
                      {currentBooking?.phone || currentBooking?.customerPhone || activePopupLane.customerPhone || "ไม่มีข้อมูลเบอร์โทร"}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">จำนวนผู้บริการ</label>
                    <div className="w-full bg-white p-3.5 rounded-2xl text-base font-bold border border-slate-200">
                      {(currentBooking?.guests || currentBooking?.guestCount || activePopupLane.guestCount || 1)} ท่าน
                    </div>
                  </div>
                </div>
              )}

              {currentBooking?.needsClubRent && (
                <div className="bg-white p-3 rounded-xl text-xs border font-bold text-slate-600">
                  🏌️ มีการเช่าอุปกรณ์ไม้กอล์ฟเพิ่มเติมในการจองคิวนี้
                </div>
              )}

              {activePopupLane.status === 'maintenance' && (
                <div className="bg-red-50 text-red-800 p-4 rounded-xl text-center font-bold text-sm border border-red-200">
                  ⚠️ เลนนี้กำลังอยู่ในสถานะปิดปรับปรุงระบบ
                </div>
              )}

              <div className="space-y-2 pt-2">
                {activePopupLane.status === 'available' && (
                  <button onClick={handleSaveWalkIn} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3.5 rounded-2xl font-black text-lg shadow-md active:scale-95 transition-transform">
                    บันทึก & เปิดเข้าใช้งานเลน
                  </button>
                )}

                {activePopupLane.status === 'booked' && (
                  <button onClick={handleCheckInBooking} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3.5 rounded-2xl font-black text-lg shadow-md active:scale-95 transition-transform">
                    กดยืนยันการเข้าใช้งาน
                  </button>
                )}

                {activePopupLane.status === 'occupied' && (
                  <button onClick={() => handleClearToAvailable('checkout')} className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3.5 rounded-2xl font-black text-lg shadow-md active:scale-95 transition-transform">
                    กดเสร็จสิ้นการใช้งาน
                  </button>
                )}

                {activePopupLane.status === 'maintenance' && (
                  <button onClick={() => handleClearToAvailable('open')} className="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-3.5 rounded-2xl font-black text-lg shadow-md active:scale-95 transition-transform">
                    กดเปิดเลนซ้อมปกติ
                  </button>
                )}

                <button onClick={() => setActivePopupLane(null)} className="w-full bg-white hover:bg-slate-100 py-2.5 rounded-xl font-bold text-sm shadow-sm border border-slate-300 active:scale-95">
                  ปิดหน้าต่าง
                </button>

                <div className="pt-2 border-t border-slate-300/60 space-y-2">
                  {activePopupLane.status === 'available' && (
                    <button onClick={handleSetMaintenance} className="w-full bg-slate-600 hover:bg-slate-700 text-white py-2 rounded-xl font-bold text-xs shadow">
                      🔧 กดปรับปรุง -> ปิดปรับปรุงเลนซ้อม
                    </button>
                  )}
                  {activePopupLane.status === 'booked' && (
                    <button onClick={() => handleClearToAvailable('cancel')} className="w-full bg-red-100 hover:bg-red-200 text-red-800 py-2 rounded-xl font-bold text-xs">
                      ❌ ยกเลิกรายการจองนี้ -> คืนสถานะเป็นเลนว่าง
                    </button>
                  )}
                </div>
              </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default LaneManagement;