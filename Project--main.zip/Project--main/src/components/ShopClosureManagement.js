import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, getDocs, addDoc, doc, deleteDoc } from "firebase/firestore";
import { theme } from '../styles/theme';

function ShopClosureManagement() {
  const [closedDates, setClosedDates] = useState([]);
  const [newClosedDate, setNewClosedDate] = useState({ date: '', reason: '' });
  const [loading, setLoading] = useState(true);

  const s = theme.admin;

  const fetchClosedDates = async () => {
    setLoading(true);
    try {
      const closureSnap = await getDocs(collection(db, "shop_closures"));
      const closureList = closureSnap.docs.map(d => ({ ...d.data(), id: d.id }));
      // เรียงลำดับตามวันที่ปิดร้านจากใกล้ไปไกล
      setClosedDates(closureList.sort((a, b) => new Date(a.date) - new Date(b.date)));
    } catch (error) {
      console.error("Error fetching closures:", error);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchClosedDates();
  }, []);

  const handleAddClosureDate = async () => {
    if (!newClosedDate.date) {
      alert("กรุณาเลือกวันที่ต้องการปิดร้าน");
      return;
    }
    try {
      await addDoc(collection(db, "shop_closures"), {
        date: newClosedDate.date,
        reason: newClosedDate.reason || "ปรับปรุงสนามประจำปี",
        createdAt: new Date()
      });
      setNewClosedDate({ date: '', reason: '' });
      fetchClosedDates();
      alert("บันทึกวันปิดร้านล่วงหน้าสำเร็จ!");
    } catch (error) {
      alert("เกิดข้อผิดพลาด: " + error.message);
    }
  };

  const handleDeleteClosureDate = async (id) => {
    if (window.confirm("คุณต้องการยกเลิกวันปิดร้านนี้ใช่หรือไม่?")) {
      await deleteDoc(doc(db, "shop_closures", id));
      fetchClosedDates();
    }
  };

  if (loading) return <div className="text-center py-10 font-bold text-slate-500">กำลังโหลดข้อมูลวันปิดร้าน...</div>;

  return (
    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 text-left font-sans">
      <div className="border-b border-slate-200 pb-4 mb-6">
        <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">📅 ตั้งวันปิดร้านล่วงหน้า (วันหยุดสนาม)</h2>
        <p className="text-slate-400 text-xs mt-1">กำหนดวันหยุดของสนามไดร์ฟกอล์ฟ เพื่อล็อกไม่ให้ระบบเปิดให้จองคิวในวันดังกล่าว</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6 bg-slate-50 p-6 rounded-3xl border border-slate-200">
        <div>
          <label className="block text-xs font-bold text-slate-500 mb-1">เลือกวันที่</label>
          <input type="date" value={newClosedDate.date} onChange={(e) => setNewClosedDate({ ...newClosedDate, date: e.target.value })} className={s.input + " !py-2.5 text-base"} />
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-500 mb-1">หมายเหตุ / เหตุผลการปิดร้าน</label>
          <input type="text" placeholder="เช่น ปรับปรุงพรมช่องไดร์ฟ..." value={newClosedDate.reason} onChange={(e) => setNewClosedDate({ ...newClosedDate, reason: e.target.value })} className={s.input + " !py-2.5 text-base"} />
        </div>
        <div className="flex items-end">
          <button onClick={handleAddClosureDate} className={s.btnEmerald + " w-full !py-3 text-base font-black"}>➕ บันทึกวันปิดร้าน</button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200 text-slate-400 text-xs font-bold uppercase">
              <th className="p-4">วันที่หยุดบริการ</th>
              <th className="p-4">เหตุผลการปิดปรับปรุง</th>
              <th className="p-4 text-right">การจัดการ</th>
            </tr>
          </thead>
          <tbody className="text-slate-600 text-sm font-medium">
            {closedDates.map((item) => (
              <tr key={item.id} className="border-b border-slate-100 hover:bg-slate-50/50 transition-all">
                <td className="p-4 text-slate-800 font-bold">{new Date(item.date).toLocaleDateString('th-TH', { year: 'numeric', month: 'long', day: 'numeric' })}</td>
                <td className="p-4 text-slate-500">{item.reason}</td>
                <td className="p-4 text-right">
                  <button onClick={() => handleDeleteClosureDate(item.id)} className="px-3 py-1 bg-red-50 text-red-600 text-xs font-bold rounded-lg hover:bg-red-100 transition-colors">
                    เปิดให้บริการปกติ
                  </button>
                </td>
              </tr>
            ))}
            {closedDates.length === 0 && (
              <tr>
                <td colSpan="3" className="text-center py-8 text-slate-400 italic">ไม่มีการตั้งวันปิดร้านล่วงหน้า</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ShopClosureManagement;