import React, { useState } from 'react';
import { theme } from '../styles/theme';
import StaffManagement from './StaffManagement';
import ClubManagement from './ClubManagement';
import CustomerManagement from './CustomerManagement'; 
import LaneManagement from './LaneManagement';
import SystemSettings from './SystemSettings';
import ShopClosureManagement from './ShopClosureManagement'; 
import BookingFlow from './BookingFlow'; // 🟢 เหลือเฉพาะตัวที่ใช้จองตัวใหม่ ตัว Management เก่าดึงออกแล้วครับ

function OwnerDashboard({ handleLogout }) { 
  const [activeTab, setActiveTab] = useState('staff');
  const s = theme.admin;

  return (
    <div className="flex min-h-screen bg-slate-50 font-sans">
      {/* --- SIDEBAR --- */}
      <div className="w-64 bg-emerald-900 text-white p-6 shadow-2xl">
        <h2 className="text-xl font-black mb-10 tracking-tighter">MLG ADMIN</h2>
        <nav className="space-y-2">
          <button onClick={() => setActiveTab('staff')} 
            className={`w-full text-left p-4 rounded-2xl font-bold transition-all ${activeTab === 'staff' ? 'bg-emerald-600 shadow-lg' : 'hover:bg-emerald-800'}`}>
            👥 จัดการพนักงาน
          </button>
          
          <button onClick={() => setActiveTab('customers')} 
            className={`w-full text-left p-4 rounded-2xl font-bold transition-all ${activeTab === 'customers' ? 'bg-emerald-600 shadow-lg' : 'hover:bg-emerald-800'}`}>
            👤 จัดการข้อมูลลูกค้า
          </button>

          <button onClick={() => setActiveTab('lanes')} 
            className={`w-full text-left p-4 rounded-2xl font-bold transition-all ${activeTab === 'lanes' ? 'bg-emerald-600 shadow-lg' : 'hover:bg-emerald-800'}`}>
            ⛳ จัดการเลนซ้อม
          </button>

          {/* 🟢 จุดเพิ่มที่ 1: เพิ่มปุ่มกดเมนู "เพิ่มการจองใหม่" ในสไลด์บาร์ */}
          <button onClick={() => setActiveTab('new_booking')} 
            className={`w-full text-left p-4 rounded-2xl font-bold transition-all ${activeTab === 'new_booking' ? 'bg-emerald-600 shadow-lg' : 'hover:bg-emerald-800'}`}>
            ➕ เพิ่มการจองใหม่
          </button>

          <button onClick={() => setActiveTab('closures')} 
            className={`w-full text-left p-4 rounded-2xl font-bold transition-all ${activeTab === 'closures' ? 'bg-emerald-600 shadow-lg' : 'hover:bg-emerald-800'}`}>
            📅 ตั้งวันปิดร้านล่วงหน้า
          </button>

          <button onClick={() => setActiveTab('clubs')} 
            className={`w-full text-left p-4 rounded-2xl font-bold transition-all ${activeTab === 'clubs' ? 'bg-emerald-600 shadow-lg' : 'hover:bg-emerald-800'}`}>
            🏌️ จัดการไม้กอล์ฟ
          </button>
          
          <button onClick={() => setActiveTab('settings')} 
            className={`w-full text-left p-4 rounded-2xl font-bold transition-all ${activeTab === 'settings' ? 'bg-emerald-600 shadow-lg' : 'hover:bg-emerald-800'}`}>
            ⚙️ ตั้งค่าค่าบริการ
          </button>
        </nav>
      </div>

      {/* --- MAIN CONTENT --- */}
      <div className="flex-1 p-10 overflow-y-auto">
        <header className="mb-10 flex justify-between items-center">
          <h1 className="text-3xl font-black text-slate-800 uppercase">
            {/* 🟢 จุดเพิ่มที่ 2: แก้ไขโครงสร้างการเลือกหัวข้อเรื่องให้ถูกต้องและรวม 'new_booking' ไว้แล้ว */}
            {activeTab === 'staff' ? 'Staff Management' : 
             activeTab === 'customers' ? 'Customer Management' : 
             activeTab === 'lanes' ? 'Lane Management' :
             activeTab === 'new_booking' ? 'Create New Booking' :
             activeTab === 'closures' ? 'Shop Closure Management' :
             activeTab === 'clubs' ? 'Club Management' : 'System Settings'}
          </h1>
          
          <button 
            onClick={handleLogout} 
            className="text-sm font-bold text-red-500 bg-red-50 px-4 py-2 rounded-xl hover:bg-red-100 transition-all shadow-sm"
          >
            ออกจากระบบ
          </button>
        </header>

        {/* แสดงเนื้อหาตามแท็บที่เลือก */}
        {activeTab === 'staff' && <StaffManagement />}
        {activeTab === 'customers' && <CustomerManagement />}
        {activeTab === 'lanes' && <LaneManagement />}
        
        {/* 🟢 จุดเพิ่มที่ 3: สั่งให้เรนเดอร์หน้าทำรายการจองเมื่อแท็บถูกสลับมาที่ 'new_booking' */}
        {activeTab === 'new_booking' && <BookingFlow />}
        
        {activeTab === 'closures' && <ShopClosureManagement />}  
        {activeTab === 'clubs' && <ClubManagement />}
        {activeTab === 'settings' && <SystemSettings />}
      </div>
    </div>
  );
}

export default OwnerDashboard;