import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, addDoc, doc, setDoc, getDocs } from "firebase/firestore";

const BookingFlow = () => {
    const [step, setStep] = useState(1);
    const [bookingData, setBookingData] = useState({
        date: '',
        time: '',
        customerName: '',
        phone: '',
        guests: 1,
        needsInstructor: false,
        needsClubRent: false
    });
    const [selectedLanes, setSelectedLanes] = useState([]);
    const [clubCart, setClubCart] = useState([]);
    const [lanesStatus, setLanesStatus] = useState({}); 
    const [clubInventory, setClubInventory] = useState([]);
    const [loading, setLoading] = useState(false);

    const TOTAL_LANES = 15;

    // 1. ดึงสถานะเลนปัจจุบันจาก Firebase เพื่อนำมาคัดกรองเลนที่ "ว่าง" เท่านั้น
    useEffect(() => {
        const fetchLanesCurrentStatus = async () => {
            try {
                const snap = await getDocs(collection(db, "lanes"));
                const statusMap = {};
                snap.forEach(doc => {
                    const data = doc.data();
                    if (data && data.laneNumber) {
                        statusMap[data.laneNumber.toString()] = data.status || 'available';
                    }
                });
                setLanesStatus(statusMap);
            } catch (err) {
                console.error("Error fetching lanes status:", err);
            }
        };
        fetchLanesCurrentStatus();
    }, [step]);

    // 2. ดึงข้อมูลไม้กอล์ฟจริงจากคอลเลกชัน "golf_clubs" (ฟิลด์ Club_Name, Quantity_Avail)
    useEffect(() => {
        const fetchClubsFromFirebase = async () => {
            setLoading(true);
            try {
                const snap = await getDocs(collection(db, "golf_clubs"));
                const data = snap.docs.map(d => {
                    const clubData = d.data();
                    return {
                        id: d.id,
                        name: clubData.Club_Name || "ไม่มีชื่ออุปกรณ์",
                        price: Number(clubData.price || 100), 
                        available: Number(clubData.Quantity_Avail ?? 0)
                    };
                });
                setClubInventory(data);
            } catch (err) {
                console.error("Error fetching golf clubs:", err);
            }
            setLoading(false);
        };

        if (step === 4) {
            fetchClubsFromFirebase();
        }
    }, [step]);

    const toggleLaneSelection = (laneNum) => {
        const currentStatus = lanesStatus[laneNum.toString()] || 'available';
        if (currentStatus !== 'available') return; // ล็อกไม่ให้เลือกเลนที่ไม่ว่าง

        if (selectedLanes.includes(laneNum)) {
            setSelectedLanes(selectedLanes.filter(l => l !== laneNum));
        } else {
            setSelectedLanes([...selectedLanes, laneNum].sort((a, b) => a - b));
        }
    };

    const handleClubCartUpdate = (club, change) => {
        const existing = clubCart.find(item => item.id === club.id);
        if (existing) {
            const newQty = Math.max(0, existing.qty + change);
            if (newQty > club.available) {
                alert(`ไม้กอล์ฟนี้พร้อมใช้งานเหลือเพียง ${club.available} ชิ้นเท่านั้น`);
                return;
            }
            if (newQty === 0) {
                setClubCart(clubCart.filter(item => item.id !== club.id));
            } else {
                setClubCart(clubCart.map(item => item.id === club.id ? { ...item, qty: newQty } : item));
            }
        } else if (change > 0) {
            if (club.available < 1) {
                alert("อุปกรณ์ชิ้นนี้หมดคลังชั่วคราว");
                return;
            }
            setClubCart([...clubCart, { ...club, qty: 1 }]);
        }
    };

    const handleBookingSubmission = async () => {
        if (!bookingData.customerName.trim() || !bookingData.phone.trim()) {
            alert("กรุณากรอกชื่อและเบอร์โทรศัพท์ติดต่อของลูกค้า");
            return;
        }

        try {
            // โครงสร้างข้อมูลใบจองมาตรฐาน (สอดคล้องกับหน้าผังเลน)
            const finalBookingData = {
                bookingDate: bookingData.date,
                bookingTime: bookingData.time,
                customerName: bookingData.customerName,
                customerPhone: bookingData.phone,
                guestCount: Number(bookingData.guests || 1),
                needsInstructor: bookingData.needsInstructor,
                needsClubRent: bookingData.needsClubRent,
                selectedLanes: selectedLanes, // เก็บเป็นอาเรย์เพื่อคุมหลายเลน
                laneNumber: selectedLanes.join(", "),
                rentedClubs: clubCart.map(i => ({ clubId: i.id, Club_Name: i.name, qty: i.qty, price: i.price })),
                status: 'pending',
                createdAt: new Date().toISOString()
            };

            // 1. บันทึกคำสั่งจองลงฐานข้อมูลคอลเลกชัน bookings
            await addDoc(collection(db, "bookings"), finalBookingData);

            // 2. วนลูปอัปเดตสถานะเลนทั้งหมดที่ถูกเลือกเป็น 'booked' (สีฟ้า) ตามโครงสร้างไอดีมาตรฐาน
            for (const num of selectedLanes) {
                const docId = `lane_${num}`;
                await setDoc(doc(db, "lanes", docId), {
                    laneNumber: num,
                    status: 'booked',
                    customerName: bookingData.customerName,
                    customerPhone: bookingData.phone,
                    guestCount: Number(bookingData.guests || 1)
                });
            }

            alert("ระบบบันทึกข้อมูลรายการจองเลนสำเร็จเรียบร้อย!");
            window.location.reload();
        } catch (err) {
            alert("เกิดปัญหาข้อผิดพลาด: " + err.message);
        }
    };

    return (
        <div className="max-w-5xl mx-auto p-4 font-sans text-slate-800">
            
            {/* 🎞&nbsp;สเต็ป 1: เลือกวันที่และเวลา */}
            {step === 1 && (
                <div className="flex flex-col items-center justify-center min-h-[500px]">
                    <div className="relative flex items-center mb-16">
                        <div className="w-10 h-8 bg-[#bbf7d0] border border-emerald-400 rounded-l-md"></div>
                        <div className="bg-[#bbf7d0] border-2 border-emerald-400 px-16 py-3 rounded-xl text-2xl font-black tracking-wide shadow-sm">
                            จองเลน
                        </div>
                        <div className="w-10 h-8 bg-[#bbf7d0] border border-emerald-400 rounded-r-md"></div>
                    </div>

                    <div className="w-full max-w-3xl bg-[#b2dfdb] rounded-2xl p-8 border border-teal-300 shadow-sm text-left">
                        <h3 className="text-xl font-bold mb-4">จองเลนใหม่</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
                            <div>
                                <label className="block text-xs font-bold text-slate-600 mb-1">วันที่จอง</label>
                                <input 
                                    type="date" 
                                    className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-sm font-bold text-slate-700 focus:outline-none" 
                                    onChange={(e) => setBookingData({ ...bookingData, date: e.target.value })}
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-600 mb-1">เริ่มที่เวลา</label>
                                <input 
                                    type="time" 
                                    className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-sm font-bold text-slate-700 focus:outline-none" 
                                    onChange={(e) => setBookingData({ ...bookingData, time: e.target.value })}
                                />
                            </div>
                        </div>

                        <div className="text-center">
                            <button 
                                onClick={() => {
                                    if(!bookingData.date || !bookingData.time) { alert("กรุณาระบุวันและเวลาก่อนดำเนินการต่อ"); return; }
                                    setStep(2);
                                }}
                                className="bg-[#00b0ff] text-white font-extrabold px-12 py-2.5 rounded-xl border-2 border-sky-500 hover:bg-sky-500 text-lg shadow-sm transition-all active:scale-95"
                            >
                                ตรวจสอบเลน
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* 🎞&nbsp;สเต็ป 2: เลือกเลน (รองรับ Multi-select) */}
            {step === 2 && (
                <div className="space-y-6">
                    <div className="bg-purple-100 p-4 rounded-xl flex items-center justify-between text-left border border-purple-200">
                        <h2 className="text-2xl font-black text-slate-800">เลือกเลน</h2>
                    </div>

                    <div className="border border-indigo-500/30 rounded-xl p-4 bg-white flex items-center justify-between shadow-sm">
                        <div className="text-lg font-bold text-slate-700">
                            เลนที่เลือก : <span className="text-indigo-600 font-black">{selectedLanes.length > 0 ? selectedLanes.join(', ') : 'ยังไม่ได้เลือก'}</span>
                        </div>
                        <button 
                            disabled={selectedLanes.length === 0}
                            onClick={() => setStep(3)}
                            className="bg-[#b9f6ca] border border-emerald-400 hover:bg-emerald-300 disabled:opacity-40 text-slate-800 font-extrabold px-6 py-2 rounded-xl transition-all"
                        >
                            ดำเนินการต่อ
                        </button>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
                        {Array.from({ length: TOTAL_LANES }, (_, i) => i + 1).map((num) => {
                            const isSelected = selectedLanes.includes(num);
                            const currentStatus = lanesStatus[num.toString()] || 'available';

                            let cardBg = "bg-[#bbf7d0] border-emerald-400"; 
                            let labelText = "ว่าง";
                            let labelBg = "bg-white text-emerald-800";

                            if (currentStatus === 'occupied') {
                                cardBg = "bg-[#fde047] border-yellow-400"; 
                                labelText = "กำลังใช้งาน";
                                labelBg = "bg-white text-amber-700";
                            } else if (currentStatus === 'booked') {
                                cardBg = "bg-[#67e8f9] border-cyan-400"; 
                                labelText = "จองแล้ว";
                                labelBg = "bg-white text-cyan-800";
                            } else if (currentStatus === 'maintenance') {
                                cardBg = "bg-[#fca5a5] border-rose-400"; 
                                labelText = "ปิดปรับปรุง";
                                labelBg = "bg-white text-rose-800";
                            }

                            const selectionStyle = isSelected ? "ring-4 ring-blue-600 ring-offset-2 scale-98 shadow-md" : "";

                            return (
                                <div 
                                    key={num}
                                    onClick={() => toggleLaneSelection(num)}
                                    className={`p-4 rounded-xl border-2 flex flex-col justify-between items-center h-40 transition-all select-none ${cardBg} ${selectionStyle} ${currentStatus === 'available' ? 'cursor-pointer hover:shadow' : 'cursor-not-allowed opacity-75'}`}
                                >
                                    <div className="w-full h-24 bg-slate-400/20 rounded-lg flex items-center justify-center text-slate-700 text-sm font-bold">
                                        LANE {num}
                                    </div>
                                    <span className={`w-full text-center text-xs font-bold py-0.5 rounded-full shadow-inner ${labelBg}`}>
                                        {labelText}
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* 🎞&nbsp;สเต็ป 3: กรอกข้อมูลรายละเอียดผู้จอง */}
            {step === 3 && (
                <div className="max-w-2xl mx-auto bg-white p-8 rounded-2xl shadow-sm border border-slate-200 text-left">
                    <div className="bg-[#b9f6ca] border border-emerald-400 py-4 text-center rounded-xl mb-8">
                        <h3 className="text-xl font-bold text-slate-800">เลนที่เลือก : {selectedLanes.join(', ')}</h3>
                    </div>

                    <div className="space-y-6">
                        <div>
                            <label className="block text-base font-bold text-slate-800 mb-1">ชื่อผู้จอง</label>
                            <input 
                                type="text"
                                placeholder="กรอกชื่อผู้รับสิทธิ์การจอง..."
                                className="w-full bg-[#ebebeb] p-3 rounded-xl focus:outline-none font-bold"
                                onChange={(e) => setBookingData({ ...bookingData, customerName: e.target.value })}
                            />
                        </div>

                        <div>
                            <label className="block text-base font-bold text-slate-800 mb-1">เบอร์โทรลูกค้า</label>
                            <input 
                                type="tel"
                                placeholder="กรอกเบอร์โทรศัพท์..."
                                className="w-full bg-[#ebebeb] p-3 rounded-xl focus:outline-none font-bold"
                                onChange={(e) => setBookingData({ ...bookingData, phone: e.target.value })}
                            />
                        </div>

                        <div>
                            <label className="block text-base font-bold text-slate-800 mb-1">จำนวนผู้เข้ามาใช้งาน (ท่าน)</label>
                            <input 
                                type="number"
                                min="1"
                                placeholder="ระบุจำนวนผู้เข้าใช้บริการ..."
                                className="w-full bg-[#ebebeb] p-3 rounded-xl focus:outline-none font-bold"
                                onChange={(e) => setBookingData({ ...bookingData, guests: Number(e.target.value) })}
                            />
                        </div>

                        <div className="space-y-4 pt-2">
                            <div>
                                <p className="text-base font-bold text-slate-800 mb-1">ต้องการผู้สอนหรือไม่?</p>
                                <div className="flex gap-4">
                                    <button 
                                        onClick={() => setBookingData({ ...bookingData, needsInstructor: true })}
                                        className={`px-6 py-2 rounded-xl text-sm font-bold flex items-center gap-1.5 border transition-all ${bookingData.needsInstructor ? 'bg-[#b9f6ca] border-emerald-400 text-slate-800 shadow-sm' : 'bg-white text-slate-400'}`}
                                    >
                                        <input type="radio" checked={bookingData.needsInstructor === true} readOnly /> ต้องการ
                                    </button>
                                    <button 
                                        onClick={() => setBookingData({ ...bookingData, needsInstructor: false })}
                                        className={`px-6 py-2 rounded-xl text-sm font-bold flex items-center gap-1.5 border transition-all ${!bookingData.needsInstructor ? 'bg-[#ff7373] border-red-300 text-slate-800 shadow-sm' : 'bg-white text-slate-400'}`}
                                    >
                                        <input type="radio" checked={bookingData.needsInstructor === false} readOnly /> ไม่ต้องการ
                                    </button>
                                </div>
                            </div>

                            <div>
                                <p className="text-base font-bold text-slate-800 mb-1">ต้องการเช่าไม้กอล์ฟหรือไม่?</p>
                                <div className="flex gap-4">
                                    <button 
                                        onClick={() => setBookingData({ ...bookingData, needsClubRent: true })}
                                        className={`px-6 py-2 rounded-xl text-sm font-bold flex items-center gap-1.5 border transition-all ${bookingData.needsClubRent ? 'bg-[#b9f6ca] border-emerald-400 text-slate-800 shadow-sm' : 'bg-white text-slate-400'}`}
                                    >
                                        <input type="radio" checked={bookingData.needsClubRent === true} readOnly /> ต้องการ
                                    </button>
                                    <button 
                                        onClick={() => setBookingData({ ...bookingData, needsClubRent: false })}
                                        className={`px-6 py-2 rounded-xl text-sm font-bold flex items-center gap-1.5 border transition-all ${!bookingData.needsClubRent ? 'bg-[#ff7373] border-red-300 text-slate-800 shadow-sm' : 'bg-white text-slate-400'}`}
                                    >
                                        <input type="radio" checked={bookingData.needsClubRent === false} readOnly /> ไม่ต้องการ
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className="flex gap-4 pt-6">
                            <button onClick={() => setStep(2)} className="flex-1 bg-[#ff7373] border border-red-400 hover:bg-red-400 text-slate-800 font-extrabold py-3 rounded-xl text-lg">
                                ย้อนกลับ
                            </button>
                            <button 
                                onClick={() => bookingData.needsClubRent ? setStep(4) : handleBookingSubmission()}
                                className="flex-1 bg-[#b9f6ca] border border-emerald-400 hover:bg-emerald-300 text-slate-800 font-extrabold py-3 rounded-xl text-lg"
                            >
                                {bookingData.needsClubRent ? 'ไปหน้าเลือกไม้กอล์ฟ' : 'ยืนยัน'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* 🎞&nbsp;สเต็ป 4: หน้าต่างเลือกไม้กอล์ฟลงตะกร้าสินค้า */}
            {step === 4 && (
                <div className="space-y-6 text-left">
                    <div className="bg-purple-100 p-4 rounded-xl border border-purple-200">
                        <h2 className="text-2xl font-black text-slate-800">เลือกไม้กอล์ฟ</h2>
                    </div>

                    <div className="flex flex-col lg:flex-row gap-6 items-start">
                        <div className="flex-[2] w-full space-y-4">
                            {loading && <p className="text-center text-slate-400 font-bold py-6">กำลังดึงข้อมูลคลังไม้กอล์ฟ...</p>}
                            
                            {!loading && clubInventory.map((club) => {
                                const cartItem = clubCart.find(i => i.id === club.id);
                                const currentQty = cartItem ? cartItem.qty : 0;

                                return (
                                    <div key={club.id} className="bg-white p-5 rounded-xl border-2 border-orange-400 flex justify-between items-center shadow-sm">
                                        <div>
                                            <h4 className="text-xl font-bold text-slate-800">{club.name}</h4>
                                            <p className="text-sm font-bold text-slate-400 mt-1">พร้อมใช้งานในคลัง : {club.available}</p>
                                        </div>
                                        
                                        <div className="flex items-center gap-4">
                                            <button onClick={() => handleClubCartUpdate(club, -1)} className="w-8 h-8 bg-[#ff7373] text-slate-800 font-black rounded-lg text-lg flex items-center justify-center">-</button>
                                            <span className="text-lg font-black w-6 text-center">{currentQty}</span>
                                            <button onClick={() => handleClubCartUpdate(club, 1)} className="w-8 h-8 bg-[#b9f6ca] text-slate-800 font-black rounded-lg text-lg flex items-center justify-center">+</button>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>

                        {/* ส่วนสรุปตะกร้าสินค้าขวามือ */}
                        <div className="flex-1 w-full lg:max-w-xs bg-[#b2f5ea] rounded-2xl p-6 border border-teal-300 shadow-sm">
                            <h3 className="text-xl font-black mb-4 tracking-wide">ตะกร้า</h3>
                            <div className="space-y-2 mb-6 max-h-60 overflow-y-auto">
                                {clubCart.map(item => (
                                    <div key={item.id} className="flex justify-between items-center bg-white p-3 rounded-lg border text-sm font-bold">
                                        <span className="truncate max-w-[130px]">{item.name}</span>
                                        <span className="bg-slate-200 px-3 py-0.5 rounded text-slate-700">{item.qty}</span>
                                    </div>
                                ))}
                                {clubCart.length === 0 && <p className="text-slate-400 italic text-center py-4 text-sm">ตะกร้าว่างเปล่า</p>}
                            </div>

                            <button onClick={handleBookingSubmission} className="w-full bg-[#b9f6ca] border border-emerald-400 hover:bg-emerald-300 text-slate-800 font-extrabold py-3 rounded-xl shadow-sm block text-center">
                                ยืนยันการจอง
                            </button>
                            <button onClick={() => setStep(3)} className="w-full text-center text-xs text-slate-500 font-bold mt-4 hover:underline">
                                ย้อนกลับ
                            </button>
                        </div>
                    </div>
                </div>
            )}

        </div>
    );
};

export default BookingFlow;