import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, getDocs, doc, updateDoc, deleteDoc } from 'firebase/firestore';

function BookingManagement() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('pending'); // ตัวกรองสถานะ: pending, confirmed, cancelled

  // 1. ฟังก์ชันดึงข้อมูลรายการจองทั้งหมดจาก Firebase
  const fetchBookings = async () => {
    setLoading(true);
    try {
      const querySnapshot = await getDocs(collection(db, 'bookings'));
      const bookingList = [];
      querySnapshot.forEach((doc) => {
        bookingList.push({ id: doc.id, ...doc.data() });
      });
      
      // เรียงลำดับตามวันเวลาที่จอง (จากจองด่วนที่สุดขึ้นก่อน)
      setBookings(bookingList.sort((a, b) => new Date(a.bookingDate) - new Date(b.bookingDate)));
    } catch (error) {
      console.error("Error fetching bookings:", error);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  // 2. 🔥 ฟังก์ชันไฮไลท์: ยืนยันการจอง และสลับสถานะเลนซ้อมเป็น "กำลังใช้งาน" ทันที (ข้อ 1.3.1.13)
  const handleConfirmBooking = async (booking) => {
    try {
      // Step A: อัปเดตสถานะของรายการจองชิ้นนี้ให้เป็น "confirmed"
      const bookingRef = doc(db, 'bookings', booking.id);
      await updateDoc(bookingRef, { status: 'confirmed' });

      // Step B: วิ่งไปเปลี่ยนสถานะผังเลนซ้อม 15 เลน (คอลเลกชัน lanes) ให้สัมพันธ์กัน
      // ค้นหาเอกสารเลน เช่น lane_1, lane_2 ตามหมายเลขเลนที่ลูกค้าจองเข้ามา
      const laneId = `lane_${booking.laneNumber}`;
      const laneRef = doc(db, 'lanes', laneId);
      
      await updateDoc(laneRef, {
        status: 'occupied', // เปลี่ยนสีการ์ดในผังเลนซ้อมเป็น "สีเหลือง - กำลังใช้งาน"
        customerName: booking.customerName || booking.customerEmail || "ลูกค้าทั่วไป"
      });

      alert(`ยืนยันการจองเลน ${booking.laneNumber} เรียบร้อย! เลนซ้อมเปิดสถานะ "กำลังใช้งาน" แล้ว`);
      fetchBookings(); // โหลดข้อมูลใหม่
    } catch (error) {
      alert("เกิดข้อผิดพลาดในการยืนยันคิว: " + error.message);
    }
  };

  // 3. ฟังก์ชันยกเลิกคำสั่งจอง
  const handleCancelBooking = async (bookingId) => {
    if (window.confirm("คุณแน่ใจใช่ไหมที่จะยกเลิกรายการจองนี้?")) {
      try {
        const bookingRef = doc(db, 'bookings', bookingId);
        await updateDoc(bookingRef, { status: 'cancelled' });
        alert("ยกเลิกรายการจองเรียบร้อยแล้ว");
        fetchBookings();
      } catch (error) {
        alert("ไม่สามารถยกเลิกได้: " + error.message);
      }
    }
  };

  // 4. ฟังก์ชันลบประวัติการจอง (Delete)
  const handleDeleteBooking = async (bookingId) => {
    if (window.confirm("ต้องการลบประวัติการจองนี้ออกจากระบบถาวรหรือไม่?")) {
      try {
        await deleteDoc(doc(db, 'bookings', bookingId));
        alert("ลบข้อมูลสำเร็จ");
        fetchBookings();
      } catch (error) {
        alert("ไม่สามารถลบได้: " + error.message);
      }
    }
  };

  // กรองตารางแสดงผลตามแท็บสถานะที่แอดมินเลือกคลิกดู
  const filteredData = bookings.filter(b => b.status === filterStatus);

  if (loading) return <div className="text-center py-10 font-bold text-slate-500">กำลังโหลดรายการจองคิว...</div>;

  return (
    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 text-left font-sans">
      <div className="border-b border-slate-200 pb-4 mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">📅 ตรวจสอบและจัดการรายการจองคิว</h2>
          <p className="text-slate-400 text-xs mt-1">อนุมัติคิวจองสนาม และกดเช็คอินเพื่อเปลี่ยนสถานะเลนซ้อมแบบเรียลไทม์</p>
        </div>
        
        {/* แถบฟิลเตอร์สลับดูสถานะการจอง */}
        <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-bold">
          <button onClick={() => setFilterStatus('pending')} className={`px-4 py-2 rounded-lg transition-all ${filterStatus === 'pending' ? 'bg-amber-500 text-white shadow' : 'text-slate-500 hover:text-slate-800'}`}>⏳ รอการยืนยัน</button>
          <button onClick={() => setFilterStatus('confirmed')} className={`px-4 py-2 rounded-lg transition-all ${filterStatus === 'confirmed' ? 'bg-emerald-600 text-white shadow' : 'text-slate-500 hover:text-slate-800'}`}>✅ เข้าใช้บริการแล้ว</button>
          <button onClick={() => setFilterStatus('cancelled')} className={`px-4 py-2 rounded-lg transition-all ${filterStatus === 'cancelled' ? 'bg-rose-500 text-white shadow' : 'text-slate-500 hover:text-slate-800'}`}>❌ ยกเลิก/ไม่มา</button>
        </div>
      </div>

      {/* --- ตารางแสดงรายการจอง (ขอบเขตข้อ 1.3.1.12) --- */}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200 text-slate-400 text-xs font-black uppercase tracking-wider">
              <th className="p-4">วัน-เวลาที่จอง</th>
              <th className="p-4">หมายเลขเลน</th>
              <th className="p-4">ข้อมูลลูกค้า / เบอร์โทร</th>
              <th className="p-4 text-center">จำนวนผู้เข้าใช้</th>
              <th className="p-4 text-center">ความต้องการพิเศษ</th>
              <th className="p-4 text-right">การจัดการคิว</th>
            </tr>
          </thead>
          <tbody className="text-slate-600 font-medium">
            {filteredData.map((booking) => (
              <tr key={booking.id} className="border-b border-slate-100 hover:bg-slate-50/40 transition-all">
                <td className="p-4">
                  <p className="text-slate-800 font-bold">{booking.bookingDate}</p>
                  <p className="text-xs text-emerald-600 font-extrabold bg-emerald-50 px-2 py-0.5 rounded-md inline-block mt-1">🕒 {booking.bookingTime || "ไม่ระบุเวลา"}</p>
                </td>
                <td className="p-4 text-center">
                  <span className="bg-indigo-50 text-indigo-700 font-black text-base px-4 py-1.5 rounded-2xl border border-indigo-100">
                    {booking.laneNumber}
                  </span>
                </td>
                <td className="p-4">
                  <p className="text-slate-800 font-bold">{booking.customerName || "ลูกค้าทั่วไป"}</p>
                  <p className="text-xs text-slate-400 font-bold">📞 {booking.customerPhone || "ไม่มีเบอร์โทร"}</p>
                </td>
                <td className="p-4 text-center font-bold text-slate-700">{booking.guestCount || 1} ท่าน</td>
                <td className="p-4 text-xs">
                  <div className="flex flex-col gap-1 items-center">
                    <span className={`px-2.5 py-0.5 rounded-md font-bold ${booking.needsClubRent ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-400'}`}>
                      {booking.needsClubRent ? "🏌️ เช่าไม้กอล์ฟ" : "✖️ ไม่เช่าไม้"}
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-md font-bold ${booking.needsInstructor ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-400'}`}>
                      {booking.needsInstructor ? "🎓 ต้องการผู้สอน (โปร)" : "✖️ ไม่ต้องการผู้สอน"}
                    </span>
                  </div>
                </td>
                <td className="p-4 text-right">
                  <div className="flex justify-end gap-2">
                    {booking.status === 'pending' && (
                      <>
                        <button onClick={() => handleConfirmBooking(booking)} className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black rounded-xl shadow-sm">
                          Confirm & Check-in
                        </button>
                        <button onClick={() => handleCancelBooking(booking.id)} className="px-3 py-1.5 bg-rose-50 text-rose-600 hover:bg-rose-100 text-xs font-bold rounded-xl">
                          ยกเลิกคิว
                        </button>
                      </>
                    )}
                    {(booking.status === 'confirmed' || booking.status === 'cancelled') && (
                      <button onClick={() => handleDeleteBooking(booking.id)} className="px-3 py-1.5 bg-slate-100 hover:bg-red-50 hover:text-red-600 text-slate-400 text-xs font-bold rounded-xl">
                        🗑️ ลบประวัติ
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
            {filteredData.length === 0 && (
              <tr>
                <td colSpan="6" className="text-center py-12 text-slate-400 italic">
                  ไม่มีรายการคำสั่งจองในหมวดหมู่นี้
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default BookingManagement;